<template>
  <section class="hero-section-wrapper py-3 py-sm-5 px-3 px-sm-6 px-lg-8">
    <div class="hero-card">
      <!-- App Header Navigation inside Hero Card -->
      <AppNavbar />

      <!-- Main Hero Body Content -->
      <v-container fluid class="hero-content px-4 px-md-10 pb-8 pb-md-12 pt-2 pt-md-4">
        <v-row align="center" no-gutters>
          <!-- Left Column: Copy & Actions -->
          <v-col cols="12" md="6" class="hero-copy">
            <p class="hero-greeting">¡Hola, Desarrollador! 👋</p>
            <h1 class="hero-title text-balance">
              ¿Qué vas a <span class="text-primary">aprender</span> hoy?
            </h1>

            <div class="quick-actions">
              <button
                v-for="action in quickActions"
                :key="action.label"
                type="button"
                class="quick-action-card"
              >
                <v-icon :icon="action.icon" size="28" color="#00E699" />
                <span>{{ action.label }}</span>
              </button>
            </div>
          </v-col>

          <!-- Right Column: Mascot Visual with Green Aura Circle & Floating Pixel Particles -->
          <v-col cols="12" md="6" class="hero-visual d-none d-md-flex">
            <div class="mascot-wrapper">
              <!-- Green Glow Background Circle -->
              <div class="glow-circle-bg"></div>

              <!-- Floating Pixel Squares -->
              <div class="pixel-square p1"></div>
              <div class="pixel-square p2"></div>
              <div class="pixel-square p3"></div>
              <div class="pixel-square p4"></div>
              <div class="pixel-square p5"></div>
              <div class="pixel-square p6"></div>
              <div class="pixel-square p7"></div>

              <!-- Mascot Robot Image -->
              <img
                src="/images/mirio-mascot.png"
                alt="Mirio, la mascota robot de la app"
                class="mascot-img"
              />
            </div>
          </v-col>
        </v-row>
      </v-container>
    </div>
  </section>
</template>

<script setup lang="ts">
const quickActions = [
  { icon: 'mdi-code-tags', label: 'Elige un\nlenguaje' },
  { icon: 'mdi-book-open-page-variant-outline', label: 'Aprende\npaso a paso' },
  { icon: 'mdi-trophy-outline', label: 'Sigue tu\nprogreso' },
]
</script>

<style scoped>
.hero-section-wrapper {
  max-width: 1400px;
  margin: 0 auto;
  width: 100%;
}

/* Main Container Div with custom dark green gradient matching screenshot */
.hero-card {
  background: linear-gradient(160deg, #051c17 0%, #03120e 100%);
  border: 1px solid rgba(0, 230, 153, 0.2);
  border-radius: 28px;
  position: relative;
  overflow: hidden;
  box-shadow: 0 24px 60px rgba(0, 0, 0, 0.65), inset 0 1px 1px rgba(0, 230, 153, 0.2);
}

.hero-greeting {
  color: #00E699;
  font-weight: 700;
  font-size: 1.05rem;
  margin-bottom: 0.5rem;
}

.hero-title {
  font-size: clamp(2.2rem, 4.2vw, 3rem);
  font-weight: 800;
  color: #FFFFFF;
  line-height: 1.15;
  margin-bottom: 2rem;
}

.text-primary {
  color: #00E699 !important;
}

.quick-actions {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 1rem;
  max-width: 600px;
}

.quick-action-card {
  background: #08211b;
  border: 1px solid rgba(0, 230, 153, 0.2);
  border-radius: 18px;
  padding: 1.25rem 0.75rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 0.65rem;
  color: #F0F6F4;
  font-weight: 600;
  font-size: 0.92rem;
  line-height: 1.25;
  text-align: center;
  white-space: pre-line;
  cursor: pointer;
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
}

.quick-action-card:hover {
  border-color: #00E699;
  background: #0d2d24;
  transform: translateY(-3px);
  box-shadow: 0 8px 24px rgba(0, 230, 153, 0.2);
}

.hero-visual {
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
}

.mascot-wrapper {
  position: relative;
  width: 100%;
  max-width: 440px;
  aspect-ratio: 1 / 1;
  display: flex;
  align-items: center;
  justify-content: center;
}

.glow-circle-bg {
  position: absolute;
  width: 85%;
  height: 85%;
  border-radius: 50%;
  background: radial-gradient(circle at 50% 50%, #00E699 0%, #10B981 60%, #04291f 100%);
  box-shadow: 0 0 60px rgba(0, 230, 153, 0.35);
}

.mascot-img {
  position: relative;
  z-index: 2;
  width: 105%;
  max-width: 480px;
  object-fit: contain;
  filter: drop-shadow(0 15px 30px rgba(0, 0, 0, 0.45));
}

/* Floating Pixel Squares matching image */
.pixel-square {
  position: absolute;
  background: #00E699;
  border-radius: 2px;
  z-index: 3;
  box-shadow: 0 0 8px rgba(0, 230, 153, 0.8);
  animation: floatPixel 4s ease-in-out infinite alternate;
}

.p1 { width: 12px; height: 12px; top: 10%; right: 12%; animation-delay: 0s; }
.p2 { width: 8px;  height: 8px;  top: 22%; left: 6%;   animation-delay: 0.7s; }
.p3 { width: 14px; height: 14px; bottom: 16%; right: 6%; animation-delay: 1.2s; }
.p4 { width: 10px; height: 10px; bottom: 10%; left: 14%; animation-delay: 1.8s; }
.p5 { width: 6px;  height: 6px;  top: 42%; right: 3%;  animation-delay: 0.4s; }
.p6 { width: 10px; height: 10px; top: 6%; left: 30%;   animation-delay: 2.2s; }
.p7 { width: 8px;  height: 8px;  bottom: 28%; left: 4%; animation-delay: 1.5s; }

@keyframes floatPixel {
  0% { transform: translateY(0px) rotate(0deg); opacity: 0.7; }
  100% { transform: translateY(-10px) rotate(12deg); opacity: 1; }
}

@media (max-width: 960px) {
  .quick-actions {
    max-width: 100%;
  }
}

@media (max-width: 600px) {
  .hero-card {
    border-radius: 20px;
  }
  .quick-actions {
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 0.5rem;
  }
  .quick-action-card {
    padding: 0.85rem 0.4rem;
    font-size: 0.8rem;
  }
}
</style>
