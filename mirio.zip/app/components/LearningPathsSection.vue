<template>
  <section class="paths-section">
    <v-container fluid class="py-8">
      <h2 class="section-title">Rutas de aprendizaje</h2>
      <p class="section-subtitle">Comienza desde cero y construye tus habilidades.</p>

      <div class="paths-grid">
        <LearningPathCard v-for="path in paths" :key="path.title" v-bind="path" />
      </div>
    </v-container>
  </section>
</template>

<script setup lang="ts">
const paths = [
  {
    title: 'Python',
    description: 'Fundamentos de Python.',
    progress: 0,
    icon: 'mdi-language-python',
    iconColor: '#4B8BBE',
    iconBg: '#122234',
  },
  {
    title: 'JavaScript',
    description: 'Lógica y desarrollo web interactivo.',
    progress: 0,
    icon: 'mdi-language-javascript',
    iconColor: '#F0DB4F',
    iconBg: '#2A2408',
  },
  {
    title: 'HTML',
    description: 'Estructura tus páginas web.',
    progress: 0,
    icon: 'mdi-language-html5',
    iconColor: '#E34F26',
    iconBg: '#2A1408',
  },
  {
    title: 'CSS',
    description: 'Diseña y da estilo a tus sitios.',
    progress: 0,
    icon: 'mdi-language-css3',
    iconColor: '#3B82C4',
    iconBg: '#0C1F33',
  },
  {
    title: 'Bases de datos',
    description: 'Conceptos básicos y consultas simples.',
    progress: 0,
    icon: 'mdi-database-outline',
    iconColor: '#34D399',
    iconBg: '#0E2A22',
  },
]
</script>

<style scoped>
.section-title {
  color: #F4F7F5;
  font-size: 1.5rem;
  font-weight: 800;
}

.section-subtitle {
  color: #92A19B;
  font-size: 0.95rem;
  margin-top: 0.25rem;
}

.paths-grid {
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 1.25rem;
  margin-top: 1.5rem;
}

@media (max-width: 1264px) {
  .paths-grid {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}

@media (max-width: 760px) {
  .paths-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 480px) {
  .paths-grid {
    grid-template-columns: 1fr;
  }
}
</style>
