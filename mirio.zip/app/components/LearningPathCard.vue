<template>
  <v-card class="path-card" rounded="lg">
    <div class="path-icon" :style="{ background: iconBg }">
      <v-icon :icon="icon" size="28" :color="iconColor" />
    </div>

    <h3 class="path-title">{{ title }}</h3>
    <p class="path-description">{{ description }}</p>

    <div class="path-progress">
      <div class="path-progress-labels">
        <span>Progreso</span>
        <span>{{ progress }}%</span>
      </div>
      <v-progress-linear
        :model-value="progress"
        color="primary"
        bg-color="#16221D"
        height="6"
        rounded
      />
    </div>

    <v-btn block color="primary" class="path-btn" rounded="lg" size="large">
      Comenzar
    </v-btn>
  </v-card>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    title: string
    description: string
    progress?: number
    icon?: string
    iconColor?: string
    iconBg?: string
  }>(),
  {
    progress: 0,
    icon: 'mdi-code-tags',
    iconColor: 'primary',
    iconBg: '#0E2A22',
  },
)
</script>

<style scoped>
.path-card {
  background: #0F1D19 !important;
  border: 1px solid #1E332C;
  padding: 1.5rem;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.path-icon {
  width: 52px;
  height: 52px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 1rem;
}

.path-title {
  color: #F4F7F5;
  font-size: 1.15rem;
  font-weight: 700;
  margin-bottom: 0.35rem;
}

.path-description {
  color: #92A19B;
  font-size: 0.88rem;
  line-height: 1.4;
  margin-bottom: 1.25rem;
  flex-grow: 1;
}

.path-progress {
  margin-bottom: 1.25rem;
}

.path-progress-labels {
  display: flex;
  justify-content: space-between;
  font-size: 0.8rem;
  color: #92A19B;
  margin-bottom: 0.5rem;
}

.path-btn {
  color: #06231A !important;
  font-weight: 700 !important;
  text-transform: none;
  box-shadow: none !important;
}
</style>
