<template>
  <header class="mirio-navbar">
    <v-container class="d-flex align-center justify-space-between py-3 py-md-4" fluid>
      <!-- Brand Logo (Official Mirio PNG Logo) -->
      <NuxtLink to="/" class="d-flex align-center text-decoration-none brand-link">
        <img src="/images/mirio-logo.png" alt="Mirio - Aprende. Programa. Crea Con IA" class="mirio-logo-img" />
      </NuxtLink>

      <!-- Right Action Controls -->
      <div class="d-flex align-center ga-3 relative-box">
        <!-- Notification Button -->
        <v-btn icon variant="flat" class="icon-btn" aria-label="Notificaciones">
          <v-badge color="#00E699" dot location="top end" offset-x="4" offset-y="4">
            <v-icon icon="mdi-bell-outline" size="22" color="#E7EDEA" />
          </v-badge>
        </v-btn>

        <!-- Main Menu Trigger Button -->
        <v-btn
          icon
          variant="flat"
          :class="['icon-btn', 'menu-trigger-btn', { 'is-active': isMenuOpen }]"
          aria-label="Abrir Menú"
          @click="toggleMenu"
        >
          <v-icon :icon="isMenuOpen ? 'mdi-close' : 'mdi-menu'" size="24" class="menu-icon-transition" />
        </v-btn>

        <!-- MIRIO ROBOTIC HAND ANIMATION CONTAINER -->
        <div :class="['mirio-hand-animator', { 'hand-extended': isMenuOpen, 'hand-retracting': isRetracting }]">
          <img src="/images/mirio-hand.svg" alt="Mano robótica de Mirio" class="mirio-robot-hand-svg" />
        </div>
      </div>
    </v-container>

    <!-- BACKDROP BLUR OVERLAY FOR MENU -->
    <Transition name="fade-backdrop">
      <div v-if="isMenuOpen" class="menu-backdrop" @click="closeMenu" />
    </Transition>

    <!-- DROPDOWN NAVIGATION MENU PULLED DOWN BY MIRIO'S HAND -->
    <Transition name="mirio-pull-down">
      <div v-if="isMenuOpen" class="mirio-dropdown-menu">
        <div class="dropdown-inner">
          <!-- Mirio Mascot Header Banner -->
          <div class="mirio-menu-header d-flex align-center ga-3 px-4 py-3 mb-4">
            <v-avatar size="44" class="mascot-avatar">
              <v-img src="/images/mirio-mascot.png" alt="Mirio Mascot" cover />
            </v-avatar>
            <div class="flex-grow-1">
              <div class="mascot-greeting">¡Hola, Desarrollador! 👋</div>
              <div class="mascot-bubble-text">¿A dónde quieres ir hoy?</div>
            </div>
            <div class="hand-pull-badge d-none d-sm-flex align-center ga-1">
              <v-icon icon="mdi-gesture-swipe-down" size="16" color="#00E699" />
              
            </div>
          </div>

          <!-- 7 REQUESTED MENU ITEMS -->
          <div class="menu-items-grid">
            <NuxtLink
              v-for="(item, index) in menuItems"
              :key="item.title"
              :to="item.link"
              class="menu-item-card text-decoration-none"
              :style="{ animationDelay: `${index * 0.05 + 0.1}s` }"
              @click="closeMenu"
            >
              <div class="item-icon-wrapper" :style="{ background: item.bgGlow }">
                <v-icon :icon="item.icon" size="24" :color="item.iconColor" />
              </div>
              <div class="item-content">
                <div class="d-flex align-center justify-space-between">
                  <span class="item-title">{{ item.title }}</span>
                  <v-badge v-if="item.badge" :content="item.badge" color="#00E699" class="item-badge" inline />
                </div>
                <span class="item-subtitle">{{ item.subtitle }}</span>
              </div>
              <v-icon icon="mdi-chevron-right" size="18" class="item-arrow" />
            </NuxtLink>
          </div>

          <!-- Bottom Footer Helper Bar -->
          <div class="menu-footer mt-4 pt-3 d-flex align-center justify-space-between">
            <div class="d-flex align-center ga-2 text-caption text-grey-lighten-1">
              <span class="status-dot"></span>
              <span>Mirio IA v2.0 • Asistente Activo</span>
            </div>
            <v-btn
              variant="text"
              density="compact"
              color="#00E699"
              class="text-none font-weight-bold text-caption"
              prepend-icon="mdi-sparkles"
              @click="closeMenu"
            >
              Preguntar a Mirio
            </v-btn>
          </div>
        </div>
      </div>
    </Transition>
  </header>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const isMenuOpen = ref(false)
const isRetracting = ref(false)

const toggleMenu = () => {
  if (isMenuOpen.value) {
    closeMenu()
  } else {
    isRetracting.value = false
    isMenuOpen.value = true
  }
}

const closeMenu = () => {
  if (!isMenuOpen.value) return
  isRetracting.value = true
  setTimeout(() => {
    isMenuOpen.value = false
    isRetracting.value = false
  }, 350)
}

// 7 EXPLICITLY REQUESTED MENU ITEMS
const menuItems = [
  {
    title: 'Inicio',
    subtitle: 'Panel principal y novedades',
    icon: 'mdi-home-variant-outline',
    iconColor: '#00E699',
    bgGlow: 'rgba(0, 230, 153, 0.12)',
    link: '/',
  },
  {
    title: 'Cursos',
    subtitle: 'Rutas de aprendizaje e IA',
    icon: 'mdi-school-outline',
    iconColor: '#38BDF8',
    bgGlow: 'rgba(56, 189, 248, 0.12)',
    badge: 'Popular',
    link: '#cursos',
  },
  {
    title: 'Practicar',
    subtitle: 'Desafíos de código en vivo',
    icon: 'mdi-code-tags',
    iconColor: '#F59E0B',
    bgGlow: 'rgba(245, 158, 11, 0.12)',
    badge: 'IA Live',
    link: '#practicar',
  },
  {
    title: 'Explorar',
    subtitle: 'Proyectos y comunidad',
    icon: 'mdi-compass-outline',
    iconColor: '#EC4899',
    bgGlow: 'rgba(236, 72, 153, 0.12)',
    link: '#explorar',
  },
  {
    title: 'Progreso',
    subtitle: 'Estadísticas y logros',
    icon: 'mdi-trophy-outline',
    iconColor: '#10B981',
    bgGlow: 'rgba(16, 185, 129, 0.12)',
    link: '#progreso',
  },
  {
    title: 'Ajustes',
    subtitle: 'Perfil y preferencias',
    icon: 'mdi-cog-outline',
    iconColor: '#A855F7',
    bgGlow: 'rgba(168, 85, 247, 0.12)',
    link: '#ajustes',
  },
  {
    title: 'Ayuda',
    subtitle: 'Soporte y documentación',
    icon: 'mdi-help-circle-outline',
    iconColor: '#00FFA6',
    bgGlow: 'rgba(0, 255, 166, 0.12)',
    link: '#ayuda',
  },
]
</script>

<style scoped>
.mirio-navbar {
  position: relative;
  z-index: 100;
  background: transparent;
  border-bottom: none;
}

.mirio-logo-img {
  height: 52px;
  width: auto;
  object-fit: contain;
  transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.brand-link:hover .mirio-logo-img {
  transform: scale(1.04);
}

.relative-box {
  position: relative;
}

.icon-btn {
  background: #0D261E !important;
  border: 1px solid rgba(0, 230, 153, 0.25);
  color: #E7EDEA !important;
  transition: all 0.25s ease;
}

.icon-btn:hover {
  background: #13382C !important;
  border-color: #00E699;
  box-shadow: 0 0 12px rgba(0, 230, 153, 0.3);
}

.menu-trigger-btn.is-active {
  background: #00E699 !important;
  color: #071913 !important;
  border-color: #00FFA6;
  box-shadow: 0 0 16px rgba(0, 230, 153, 0.6);
}

.menu-icon-transition {
  transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
}

/* ========================================================== */
/* MIRIO ROBOTIC HAND PULL-DOWN ANIMATION STYLES             */
/* ========================================================== */

.mirio-hand-animator {
  position: absolute;
  top: 100%;
  right: 0;
  width: 140px;
  height: 260px;
  pointer-events: none;
  z-index: 120;
  opacity: 0;
  transform: translateY(-160px) scaleY(0.4);
  transform-origin: top center;
  transition: all 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.mirio-robot-hand-svg {
  width: 100%;
  height: 100%;
  object-fit: contain;
  filter: drop-shadow(0 8px 20px rgba(0, 230, 153, 0.4));
}

.mirio-hand-animator.hand-extended {
  opacity: 1;
  animation: mirioArmPullDown 0.6s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
}

.mirio-hand-animator.hand-retracting {
  animation: mirioArmRetract 0.35s ease-in forwards;
}

@keyframes mirioArmPullDown {
  0% {
    opacity: 0;
    transform: translateY(-140px) scaleY(0.3) rotate(-10deg);
  }
  40% {
    opacity: 1;
    transform: translateY(20px) scaleY(1.15) rotate(4deg);
  }
  70% {
    transform: translateY(-5px) scaleY(0.95) rotate(-2deg);
  }
  100% {
    opacity: 1;
    transform: translateY(0) scaleY(1) rotate(0deg);
  }
}

@keyframes mirioArmRetract {
  0% {
    opacity: 1;
    transform: translateY(0) scaleY(1);
  }
  100% {
    opacity: 0;
    transform: translateY(-160px) scaleY(0.3);
  }
}

/* ========================================================== */
/* DROPDOWN MENU CONTAINER & TRANSITION                      */
/* ========================================================== */

.menu-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(4, 14, 11, 0.7);
  backdrop-filter: blur(8px);
  z-index: 105;
}

.mirio-dropdown-menu {
  position: absolute;
  top: 100%;
  right: 16px;
  width: calc(100vw - 32px);
  max-width: 440px;
  background: linear-gradient(165deg, rgba(12, 34, 27, 0.96) 0%, rgba(6, 19, 15, 0.98) 100%);
  border: 1.5px solid rgba(0, 230, 153, 0.35);
  border-radius: 24px;
  padding: 20px;
  z-index: 110;
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.7), 0 0 30px rgba(0, 230, 153, 0.25);
  overflow: hidden;
  transform-origin: top right;
}

/* Vue Transitions for Dropdown Menu */
.mirio-pull-down-enter-active {
  animation: menuElasticPullDown 0.55s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
}

.mirio-pull-down-leave-active {
  animation: menuElasticRetract 0.35s cubic-bezier(0.4, 0, 0.2, 1) forwards;
}

@keyframes menuElasticPullDown {
  0% {
    opacity: 0;
    transform: translateY(-60px) scale(0.85);
  }
  50% {
    opacity: 1;
    transform: translateY(12px) scale(1.02);
  }
  75% {
    transform: translateY(-4px) scale(0.99);
  }
  100% {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
}

@keyframes menuElasticRetract {
  0% {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
  100% {
    opacity: 0;
    transform: translateY(-40px) scale(0.9);
  }
}

.fade-backdrop-enter-active,
.fade-backdrop-leave-active {
  transition: opacity 0.3s ease;
}

.fade-backdrop-enter-from,
.fade-backdrop-leave-to {
  opacity: 0;
}

/* ========================================================== */
/* MENU CONTENT & CARD STYLING                                */
/* ========================================================== */

.mirio-menu-header {
  background: rgba(0, 230, 153, 0.08);
  border: 1px solid rgba(0, 230, 153, 0.2);
  border-radius: 16px;
}

.mascot-avatar {
  background: #0E2A22;
  border: 1.5px solid #00E699;
}

.mascot-greeting {
  font-size: 0.95rem;
  font-weight: 700;
  color: #FFFFFF;
}

.mascot-bubble-text {
  font-size: 0.8rem;
  color: #00E699;
  font-weight: 600;
}

.hand-pull-badge {
  font-size: 0.7rem;
  color: #9CA8A4;
  background: rgba(0, 0, 0, 0.3);
  padding: 4px 8px;
  border-radius: 20px;
  border: 1px stroke rgba(0, 230, 153, 0.2);
}

.menu-items-grid {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.menu-item-card {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 12px 14px;
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.07);
  border-radius: 16px;
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  animation: itemFadeSlide 0.35s ease-out backwards;
}

.menu-item-card:hover {
  background: rgba(0, 230, 153, 0.1);
  border-color: rgba(0, 230, 153, 0.4);
  transform: translateX(6px);
  box-shadow: 0 4px 16px rgba(0, 230, 153, 0.15);
}

.item-icon-wrapper {
  width: 42px;
  height: 42px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.item-content {
  flex-grow: 1;
}

.item-title {
  font-weight: 700;
  font-size: 0.95rem;
  color: #F0F6F4;
}

.item-subtitle {
  display: block;
  font-size: 0.78rem;
  color: #8E9E98;
}

.item-arrow {
  color: #5C6E67;
  transition: transform 0.2s ease, color 0.2s ease;
}

.menu-item-card:hover .item-arrow {
  color: #00E699;
  transform: translateX(4px);
}

.menu-footer {
  border-top: 1px solid rgba(255, 255, 255, 0.08);
}

.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #00E699;
  box-shadow: 0 0 8px #00E699;
  display: inline-block;
}

@keyframes itemFadeSlide {
  0% {
    opacity: 0;
    transform: translateY(10px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 600px) {
  .mirio-logo-img {
    height: 42px;
  }
  .mirio-dropdown-menu {
    right: 8px;
    width: calc(100vw - 16px);
    padding: 16px;
  }
}
</style>
